#ifndef ANDROID_H
#define ANDROID_H

void preventRemoveOfSymbolsDuringLinking();

#endif //ANDROID_H
